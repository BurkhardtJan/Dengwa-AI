# MiniMedi

A universal, standalone media viewer for text, PDF, audio, video, EPUB,
FB2/MOBI/AZW3 books, images, comic archives (CBZ, CBR, CB7, CBT, compressed tar), and subtitles (SRT, VTT, LRC, UltraStar lyrics).

MiniMedi knows nothing about **users, AI, databases, or learning logic**.
It renders media and fires events about the interaction (text selection,
position, play state). What happens with those events is entirely up to
the host application — e.g. [Dengwa AI](https://github.com/BurkhardtJan).

## Status

In development (package version 0.1.0, not yet released) — text, audio,
video, PDF (canvas or iframe), EPUB, FB2/MOBI/AZW3 books, and standalone subtitle
transcripts are all functional, with a full event
set: position tracking, text selection, and synced subtitles (SRT/VTT, LRC and UltraStar lyrics).
Subtitles support multiple simultaneous tracks (external files and/or
embedded MKV/MP4 tracks) - e.g. a target-language and a native-language
track shown at once. EPUB supports linear navigation plus a
table-of-contents sidebar. Images and comic archives (CBZ, CBR, CB7, CBT and
compressed tar, read page by page) are supported too. Comics, EPUB and e-books can
open where the reader stopped (`startPage`, `startCfi`, `startChapter`/`startProgress`).
No plugin system yet.

React-only for now (React is a peer dependency). The `core/` module
(types, event bus, source resolution, subtitle parsing) has zero React
dependency by design, so it can be reused if MiniMedi ever needs to
support other frameworks or plain JS.

License: to be decided — depends on which further dependencies MiniMedi
ends up with. Do not publish or distribute outside this project until a
license is chosen.

## Install (local, during development)

Requires Node 22 (`nvm use` picks it up from `.nvmrc`) and
[pnpm](https://pnpm.io/). pnpm blocks dependency install scripts unless they
are approved - the decisions live in `pnpm-workspace.yaml`.

```bash
pnpm install
```

## Run the demo

```bash
pnpm dev
```

Opens the demo app under `examples/demo-app` with live reload. The demo
is a small file-upload player: pick a file from your machine and it's
displayed immediately via MiniMedi (see `examples/demo-app/App.tsx`).

PDF (canvas mode) works in the demo out of the box; see
[PDF mode](#pdf-mode) for how the PDF.js worker is loaded.

## React versions

MiniMedi works with React 18 and 19 (`peerDependencies`: `^18.0.0 || ^19.0.0`). Development
and the lockfile stay on React 18; CI runs typecheck, unit tests and the browser tests
against both. To try React 19 locally without committing it:

```bash
pnpm add -D react@^19 react-dom@^19 @types/react@^19 @types/react-dom@^19
pnpm typecheck && pnpm test
git checkout package.json pnpm-lock.yaml && pnpm install   # back to React 18
```

Code that has to type-check under both: `useRef` always gets an initial value
(`useRef<T | undefined>(undefined)`), and a ref a component receives is typed
`RefObject<T | null>`.

## Tests

```bash
pnpm test            # Vitest: subtitle parsing + embedded MKV/MP4 extraction
pnpm fixtures    # (re)generate the test media in tests/fixtures/
```

The embedded-subtitle tests run against real MKV/MP4 files generated with
`ffmpeg` (`scripts/make-fixtures.sh`, called automatically by `pnpm test`).
They are skipped if `ffmpeg` is not installed. The tests run in Node, so
they do not cover browser-specific issues (e.g. the Node polyfills in
`vite.config.ts`) - check those with `pnpm dev` and a real file.

## Build as a library

```bash
pnpm build
```

Produces `dist/minimedi.js` (ESM), lazy-loaded chunks in `dist/chunks/`,
`dist/style.css`, and TypeScript type declarations. There is no UMD/CJS
build: the heavy viewers are code-split, which UMD does not support.

The entry itself is small (about 11 kB gzipped). These parts are only
downloaded when needed:

| Chunk | Loaded when | Approx. gzip |
| --- | --- | --- |
| PDF viewer (react-pdf/pdf.js) | a PDF is shown in `pdfMode="canvas"` | 133 kB |
| default pdf.js worker | the first PDF, unless you call `configurePdfWorker()` | 457 kB |
| EPUB viewer (epubjs) | an EPUB is shown | 139 kB |
| e-book viewer (FB2/MOBI/AZW3, foliate-js) | an e-book is shown | 2.5 kB + 3 kB (FB2) or 9 kB + 2 kB (MOBI/AZW3) |
| comic viewer (CBZ reader) | a comic archive is shown | 4 kB (+ pako, 11 kB, shared with the parsers below) |
| JPEG 2000 decoder (worker + jpeg2000) | the first JPEG 2000 image or comic page | 11 kB |
| RAR/7z/tar reader (libarchive.js, worker, WASM) | the first RAR, 7z or tar comic archive (CBR, CB7, CBT) | 648 kB (1.4 MB) + 34 kB |
| container parsers (MKV/MP4) | a video is scanned for embedded subtitles | 106 kB |
| image subtitles (libpgs + its worker) | an image (PGS) track is selected | 27 kB + 32 kB |

## Usage

```tsx
import { MiniMedi } from "minimedi";
import "minimedi/dist/style.css"; // required for correct PDF text-layer rendering

function App() {
  return (
    <MiniMedi
      source={{ type: "video", url: "/movie.mp4", title: "Episode 1" }}
      onTextSelection={(text) => console.log("selected:", text)}
      onEvent={(event) => console.log(event)}
    />
  );
}
```

Without the stylesheet, the PDF viewer's text/annotation layers render as
visible, misplaced text instead of an invisible overlay. Not needed
during `pnpm dev` in this repo — Vite injects styles automatically
there; it only matters once you consume the built package.

### `MediaSource`

```ts
interface MediaSource {
  id?: string;
  type: "text" | "pdf" | "audio" | "video" | "epub" | "subtitle" | "image" | "comic" | "ebook";
  url: string;
  title?: string;
  blob?: Blob;                                       // the File behind `url`: read directly instead of downloading (embedded scan, comics, e-books)

  // video / audio / subtitle
  subtitleUrls?: Array<string | SubtitleFile>;       // external SRT/VTT/LRC/UltraStar files, shown together; objects add label/lang
  embeddedSubtitleTrackIds?: Array<string | number>; // embedded MKV/MP4 tracks to extract
  subtitleLayout?: SubtitleLayout;                   // hide / move subtitle tracks
  mediaUrl?: string;                                 // for type "subtitle": attached video/audio
  mediaKind?: "audio" | "video";                     // for type "subtitle"; defaults to "video"
  startTime?: number;                                // audio/video: where to start (seconds); also moves an open player
  coverUrl?: string;                                 // audio (also a transcript with attached audio): cover image above the player
  scanEmbeddedSubtitles?: boolean;                   // video: look for embedded tracks (default true)
  embeddedScanMaxBytes?: number;                     // MP4 only: skip files above this size (default 1 GB)
  prefetchEmbeddedSubtitles?: boolean;               // read all embedded tracks in one pass (default off)
  nativeControls?: boolean;                          // video: the browser's own controls instead of ours

  // comic ("comic"), see "Images and comic archives"
  startPage?: number;                                // 1-based; a changed value moves an open comic

  // e-book ("ebook") and EPUB ("epub"): where to open, e.g. from an earlier positionChange
  startChapter?: number;                             // e-book: 1-based; a changed value moves an open book
  startProgress?: number;                            // e-book: 0 to 1 within that chapter
  startCfi?: string;                                 // EPUB: a `cfi` from positionChange; a changed value moves an open book
  pageView?: "single" | "double" | "scroll";         // how pages are shown at first
  readingDirection?: "ltr" | "rtl";                  // "rtl" for manga

  // image and comic: recognized text over the picture, see "Recognized text (hOCR)"
  ocr?: string | Blob | OcrPage[];                   // hOCR (string, Blob/File) or pages read with parseHocr
}
```

The fields are grouped by the type they are meant for, and each is described
where that type is. An `ebook` needs no option: its format is recognized by the
file's first bytes.

### Events

MiniMedi fires, among others:

- `mediaLoaded` — media has loaded (with `duration`/`pages`/`chapters`/`cues`/`width`+`height` where applicable)
- `positionChange` — position changed (`page`, `time`, `cfi` for EPUB, or `chapter` and `progress` for FB2/MOBI/AZW3)
- `searchChange` — the search in the recognized text changed (`query`, `total` matches in the whole book, `current` match counted from 1 or 0, `page` of that match for comics)
- `selection` — text was selected (`text`, and `position`: `page`, `time`, `cfi`, or `chapter` and `progress`; for text picked from an OCR layer also `region`, see "Recognized text")
- `playStateChange` — play/pause toggled
- `subtitleChange` — a subtitle cue became active, once per cue (tagged with `source` when multiple tracks are active at once)
- `subtitleEnd` — the cue ended and no other one follows right away (gap, seek, or the track was switched off); a cue that is directly followed by the next one sends only `subtitleChange`. Same `source` rule as above. Not sent when the viewer is closed
- `tracksAvailable` — embedded subtitle tracks were detected in a video file: `tracks` can be selected (text tracks, and image tracks with `kind: "image"`), `unsupportedTracks` lists subtitle tracks that exist but cannot be shown (see below)
- `embeddedSubtitlesProgress` — progress of reading a video to extract selected embedded tracks (`loadedBytes`, `totalBytes?`, `done`)
- `error` — something failed to load (see below)

All event types live in [`src/core/types.ts`](./src/core/types.ts).

#### Errors

Failures are reported as `{ event: "error", scope, message, url?, fatal }`:

| `scope` | Meaning | `fatal` |
| --- | --- | --- |
| `"media"` | the audio/video/PDF/EPUB/e-book/image/comic archive itself could not be loaded | `true` (for an attached media of a subtitle transcript: `false`; for one unreadable page of a comic archive: `false`) |
| `"subtitle"` | one external subtitle file failed (HTTP error, network); the other tracks keep working | `false` (`true` if it is the primary file of a `"subtitle"` source) |
| `"cover"` | the cover image (`coverUrl`) could not be loaded; it is left out and the player keeps working | `false` |
| `"embeddedSubtitles"` | the embedded-track scan or extraction failed or was skipped (MP4 over `embeddedScanMaxBytes`, no CORS, ...) | `false` |
| `"ocr"` | `MediaSource.ocr` could not be read (not hOCR, no pages, over 64 MiB); the picture is shown without the text layer | `false` |

If the embedded scan fails or is skipped, `tracksAvailable` is also fired
with an empty list. `TextViewer` and `pdfMode="iframe"` use plain
`<iframe>`s, for which browsers expose no load errors, so they never emit
`error`.

### PDF mode

```tsx
<MiniMedi source={pdfSource} pdfMode="canvas" />  // default: react-pdf/pdf.js, page/position events
<MiniMedi source={pdfSource} pdfMode="iframe" />  // browser's built-in PDF renderer, no page events
```

`"iframe"` loads nothing extra. `"canvas"` loads the PDF viewer on demand,
plus a pdf.js worker. By default that is a worker bundled with MiniMedi
(a large chunk, but zero config). To serve the worker yourself instead,
call this once at startup, before the first PDF is shown:

```ts
import { configurePdfWorker } from "minimedi";

// Copy node_modules/pdfjs-dist/build/pdf.worker.min.mjs into your public
// folder (or serve it from anywhere else) and point MiniMedi at it:
configurePdfWorker({ workerSrc: "/pdf.worker.min.mjs" });
```

The worker file must come from the same `pdfjs-dist` version that MiniMedi
installs (pdf.js refuses to run if the versions differ), so re-copy it
after updating. pdf.js 5 is built for current browsers; MiniMedi does not
use its `legacy` build for older ones. The bundled default is then never downloaded. If a lazily loaded viewer
cannot be fetched (offline, broken deploy), MiniMedi shows a message and
fires a fatal `error` event instead of crashing your app.

### Start position of audio and video (`startTime`)

`MediaSource.startTime` (seconds) puts audio, video and a transcript's attached media at a
saved position once the file's length is known. The `time` of `positionChange` events is
what to save. It is clamped to the length of the media; a missing, negative or
non-numeric value starts at 0. Playback is **not** started by it (there is no autoplay).

A changed value moves an open player there, like `startPage` does for comics. The player's
own playing never changes the prop, and a value within half a second of the current
position causes no jump. Pass the position you *saved*, not the live one; feeding each
`positionChange` straight back would mean a seek per update.

### Fullscreen for documents (`fullscreenButton`)

Video has a fullscreen button in its control bar. For documents, set
`fullscreenButton` on `<MiniMedi>`: text, PDF, EPUB, e-books, images and comics then get a
button above them, and the viewer fills the screen (iframes, the EPUB page and the PDF
page take the screen's height). Only MiniMedi's own frame goes fullscreen, so the page
controls, the search bar and the page slider stay inside it. Escape leaves fullscreen.
Audio and transcripts have nothing to enlarge and get no button.

With `fullscreenButton` there is a second button, next to the fullscreen one (or the **H** key
while the viewer has the focus), that hides the controls: the page buttons, the jump control, the
contents list and the search bar of comics, PDFs, e-books and EPUBs. Only the two buttons stay,
laid over the page's corner (dimmed), and the page takes the room (in fullscreen the PDF page, the
comic page and the EPUB page grow). The keys and swipes of the viewer keep working while the controls
are hidden. Labels: `hideControls`, `showControls`.

The default is `false`: nothing is added to the page. Without a fullscreen API in the
browser the button is left out. The frame's colors in fullscreen are `--minimedi-bg` and
`--minimedi-fg` (default: the browser's `Canvas` and `CanvasText`, which follow the
page's `color-scheme`). If you prefer your own button, call `requestFullscreen()` on a
container of your own around `<MiniMedi>`; the viewers then keep their normal size.

### Dark mode and colors

MiniMedi draws few colors itself, and they follow the page's `color-scheme`: set
`color-scheme: dark` (or `light dark`) on `<html>` and the texts, lines and the fullscreen
frame follow. Each color can be set with a CSS variable on any ancestor:

| Variable | What | Default |
| --- | --- | --- |
| `--minimedi-error` | text of an error message | crimson, lighter on a dark page |
| `--minimedi-border` | line around a document frame and beside a contents list | the text color at 20% |
| `--minimedi-highlight` | current entry of a contents list, current subtitle line | translucent yellow |
| `--minimedi-bg`, `--minimedi-fg` | background and text of the fullscreen frame | `Canvas`, `CanvasText` |

```css
:root { --minimedi-error: #ff6b6b; --minimedi-border: #444; }
```

The defaults use `color-mix()` (browsers from 2023 on); in an older one the property keeps its
inherited value. Not themed on purpose: the video controls and the subtitle text over a
video (white on dark, over the picture in every theme).

E-books (FB2, MOBI, AZW3) take the page's scheme for the chapter's own colors (a dark page gets
light text on a dark chapter). It is read when a chapter loads and again when the attributes of
`<html>` or `<body>` change, as a theme toggle does. Not covered: the content of text, PDF and
EPUB frames. Those are documents with their own colors (a PDF page stays white, like paper).

### Audio cover

`MediaSource.coverUrl` shows a cover image (album art, say) above the player of an
`audio` source, and of a `subtitle` source with attached audio (`mediaKind: "audio"`).
It is optional and only decoration: without it nothing changes, and one that cannot
be loaded is left out and reported as a non-fatal `error` with scope `"cover"`. The
image is fitted into the width and at most half the screen height (20 rem at most),
with its proportions kept; its alternative text is "Cover: <title>". Under a strict
Content-Security-Policy the URL needs `img-src` (`blob:`, `data:` or the host that
serves it). MiniMedi does not read covers out of the audio file (ID3, MP4 or FLAC
tags): the host passes the image.

```tsx
<MiniMedi source={{ type: "audio", url: "/song.mp3", title: "Song", coverUrl: "/song.jpg" }} />
```

### Subtitles

`AudioViewer`/`VideoViewer` accept `subtitleUrls` (multiple external
SRT/VTT/LRC/UltraStar files, all shown simultaneously):

```tsx
<MiniMedi
  source={{
    type: "video",
    url: "/movie.mp4",
    subtitleUrls: ["/movie.en.srt", "/movie.de.srt"],
  }}
  onEvent={(event) => {
    if (event.event === "subtitleChange") console.log(event.source, event.text);
  }}
/>
```

**Naming the tracks.** The menu names an external file by the file name in its URL, which
says nothing for a `blob:` URL. Give an entry as an object to name it and tell its language:

```tsx
subtitleUrls: [
  { url: blobUrlEn, label: "English", lang: "en" },
  { url: blobUrlDe, label: "Deutsch", lang: "de" },
  "/movie.fr.srt", // a plain URL still works
]
```

`label` is shown in the subtitle menu (and in its eye button's name); `lang` (a BCP 47 tag) is
set as the `lang` attribute of the menu entry and of the drawn text, so screen readers and
the browser's font choice know the language. MiniMedi does not interpret it. Events
(`subtitleChange.source`) and `subtitleLayout` keep identifying the track by its `url`.

**Embedded tracks (MKV/MP4):** `VideoViewer` also detects subtitle tracks
already embedded in the video container itself. Detection happens
automatically; extraction only happens for tracks you explicitly select:

```tsx
function Player() {
  const [source, setSource] = useState<MediaSource>({ type: "video", url });

  return (
    <MiniMedi
      source={source}
      onEvent={(event) => {
        if (event.event === "tracksAvailable") {
          // event.tracks: EmbeddedSubtitleTrack[] ({ id, language, name, container })
          setSource((s) => ({ ...s, embeddedSubtitleTrackIds: [event.tracks[0].id] }));
        }
      }}
    />
  );
}
```

Supported:
- **Text subtitles:** MKV (via `matroska-subtitles`: SRT/SSA/ASS) and MP4
  (via `mp4box`: `mov_text`/3GPP Timed Text). Shown as text, with
  `subtitleChange` events.
- **Image subtitles (PGS, as on Blu-rays), MKV only:** drawn onto a canvas
  over the video with [libpgs](https://www.npmjs.com/package/libpgs) (MIT),
  at the position the disc authors chose. They are bitmaps, so there is no
  text and no `subtitleChange` event for them (OCR could add that later).
  Selecting several image tracks stacks them upwards (12 % of the video
  height per track) as a placeholder until subtitles can be positioned.
  libpgs runs in a worker; see `configurePgsWorker({ workerSrc })` if a
  strict CSP or cross-origin isolation blocks the bundled `data:` worker.

Not supported: other image formats (VobSub, DVB) and WebVTT/TTML boxed
inside MP4 (`wvtt`, `stpp`).

Such tracks are not silently ignored: they are reported in
`tracksAvailable.unsupportedTracks` (`{ id, language?, name?, codec,
container }`), and `describeSubtitleCodec(codec)` turns the codec id into a
readable name ("VobSub (image-based, from DVD)"). A host can therefore say
"this file has subtitles, but they cannot be shown" instead of "no
subtitles". (PGS tracks are not listed there: they are offered as image
tracks in `tracks`.)

This is the second intentional exception to MiniMedi's "never fetch data
itself" rule (the first is loading external subtitle files): reading a
video's raw bytes to parse its container format requires fetching the
whole file. Detection reads only as much as needed to find track
metadata; extraction reads the whole file once per selected track.

`VideoViewer` stacks all active cues (external + embedded) as an overlay;
`AudioViewer` stacks them below the player.

### Turning pages: keyboard and swiping

PDFs, comics, e-books and EPUBs turn pages the same way. The keys work while the viewer has
the focus (click into it, or tab to it):

| Key | Does |
| --- | --- |
| right / left arrow | next / previous page (swapped for a right-to-left comic) |
| Page Down, Space | next page; Shift+Space and Page Up go back |
| Home, End | first / last page |

An e-book's chapter scrolls, so there only the left and right arrow turn chapters and the other
keys keep scrolling it. The same goes for the scroll view of a comic (Page Up/Down, Space and the
up/down arrows scroll). Keys typed in a field, on a button, a link or a slider are theirs and do
not turn pages. Anything with Ctrl, Alt or Meta is left to the browser.

Swiping sideways with a finger or a pen goes to the next page (to the left; to the right for a
right-to-left comic) or back. A swipe is at least 50 px long, mostly sideways and quick; dragging to
select text and a zoomed comic page that scrolls sideways are not swipes. A mouse never swipes.
Inside a frame (a book's chapter, an EPUB page) the keys and swipes work as well.

```tsx
<MiniMedi source={source} navigation={{ keyboard: false }} /> // your app has its own keys
<MiniMedi source={source} navigation={{ swipe: false }} />
```

Both are on by default. (`MiniMediNavigationProvider` does the same for an exported viewer used
on its own.)

### Jump to

Comics, PDFs, e-books (FB2, MOBI, AZW3) and EPUBs share one "jump to" control: a slider and a
number field with a Go button (`PageJump`, class `minimedi-page-jump`; the comic keeps its
`minimedi-comic-jump`). The slider moves when it is let go of, the field on Enter or Go; a number
outside the book is kept inside it, and keys typed there do not turn pages. For PDFs and comics
the unit is the page ("Go to page"), for e-books and EPUBs the chapter, i.e. the spine item
that the `chapters` count of `mediaLoaded` is made of ("Go to chapter"; labels `goToChapter`,
`chapterSlider`, `chapterOf`). An EPUB has no fixed pages (it is reflowable), so there is no
"go to percent" there.

### EPUB

Rendered via [`epubjs`](https://github.com/futurepress/epub.js/), each
chapter in a sandboxed `<iframe>` with scripts disabled by default (same
security model as `TextViewer`/`PdfViewerIframe`). Position is tracked
via **CFI** (Canonical Fragment Identifier) instead of a page number,
since EPUB is reflowable text with no fixed pagination. `Previous`/`Next`
buttons navigate linearly; if the book has a table of contents, a
clickable sidebar is rendered alongside the reader (nested TOCs
supported) and highlights the current chapter/section.

To continue where the reader stopped, keep the `position.cfi` of the last
`positionChange` and pass it back as `MediaSource.startCfi`. A value that cannot
be read opens the book at its start. A changed `startCfi` moves an open book
there (the reader's own turning does not change it).

### E-books (FB2, MOBI, AZW3)

`type: "ebook"` opens a reflowable book that is not an EPUB: **FB2**, **MOBI**
and **AZW3** (KF8). The format is recognized by the file's first bytes, so a
wrong file extension does not matter; a file that is none of these gives a
fatal `error` that says so. Pass `MediaSource.blob` to read a file directly,
otherwise the URL is downloaded once. The books are read by the modules
`fb2.js` and `mobi.js` of [foliate-js](https://github.com/johnfactotum/foliate-js)
(MIT), loaded only when such a book is opened.

```tsx
<MiniMedi source={{ type: "ebook", url, blob: file }} onEvent={...} />
```

- **Reading.** One chapter at a time in a sandboxed frame, with a table of
  contents beside it (the book's own; if it has none, one made from the
  headings), `Previous`/`Next` for the chapter, and links inside the book that
  move between chapters. How a book is cut into chapters is up to the book: in the
  tested files a MOBI is cut at its page breaks and an FB2 has its title page as the
  first chapter.
- **Events.** `mediaLoaded` has `chapters`. `positionChange` and `selection` carry
  `position.chapter` (counted from 1) and `position.progress` (how far down the
  chapter, 0 to 1; position events follow the scrolling after it has stopped).
- **Start position.** `MediaSource.startChapter` (counted from 1, clamped to the
  book) and `startProgress` (0 to 1 of that chapter) open the book where the
  reader stopped: pass back `position.chapter` and `position.progress` of the last
  `positionChange`. Without them the book opens at the top of its first chapter;
  a `startProgress` alone applies to that chapter. A changed value moves an open
  book (the reader's own turning does not change it). The place is applied once
  the chapter has loaded, so the `positionChange` that follows reports where the
  reader really is.
- **Safe by construction.** The frame has `sandbox="allow-same-origin"` (no
  scripts), the chapter is rebuilt from the book's text and styles, scripts,
  frames, objects and foreign links are removed, and a policy in the page allows
  only the book's own pictures, fonts and styles (`blob:` and `data:` URLs):
  a book cannot load anything from the network. Links never navigate the frame;
  addresses outside the book do nothing.
- **Content-Security-Policy.** A page with a strict policy needs `connect-src
  blob:` (a chapter is read back from a `blob:` URL), and `img-src blob:`,
  `font-src blob:` and `style-src blob:` for the frame.
- **FB2 in a ZIP.** A `.fb2.zip` (the usual way FB2 books are shared) opens like an
  FB2: the first `.fb2` file of the ZIP is unpacked in memory (stored or
  deflate, up to 256 MB; hidden files and macOS metadata are skipped). The ZIP is
  recognized by its bytes, not its name. One without an FB2 file, such as an
  EPUB, is refused with a message.
- **Limits.** Books with DRM are not supported. Only these two modules of foliate-js are used,
  at one exact version; its authors warn that its API can change, so updating it
  is a deliberate step. Tested with a hand-written FB2 (UTF-8 and windows-1251)
  and a calibre-made MOBI 6 and AZW3; other makers' files are not tested.

### Images and comic archives

`type: "image"` shows one image (JPEG, PNG, GIF, WebP, SVG, ... whatever the
browser can draw in an `<img>`), fitted to the viewer; a click toggles the
natural size. `mediaLoaded` carries its `width` and `height`. JPEG 2000 files
(`.jp2`), which only Safari shows natively, are recognized by their content
and decoded as described below; any other file the browser cannot draw ends
in a fatal `error` event.

`type: "comic"` opens a comic book archive: **CBZ** (a ZIP of images), **CBR**
(a RAR), **CB7** (a 7z) and **CBT** (a tar), also a gzip, bzip2 or xz compressed
tar (`.tar.gz`, `.tar.bz2`, `.tar.xz`). The format is recognized by the
file's first bytes, so a `.cbr` that really is a ZIP opens fine. The viewer shows one page at a time
(`Previous`/`Next`, Arrow keys, PageUp/PageDown, Home/End; `Page n / N`) and
reports `mediaLoaded` with `pages` and `positionChange` with `page` (1-based).

- Pages are the image entries (JPEG, PNG, GIF, WebP, AVIF, BMP, JPEG 2000),
  in natural order by path (`p2.jpg` before `p10.jpg`). Hidden files and `__MACOSX/` are
  skipped. AVIF and WebP only show where the browser supports them.
- Pass `blob` (e.g. the `File` behind the object URL) to read the archive
  without a download; otherwise the URL is fetched once. Only the archive's
  directory and the pages next to the current one are read and decompressed,
  so large archives do not have to fit in memory.
- ZIP archives are read by MiniMedi's own reader: stored and deflate entries and Zip64. It
  does not handle encrypted archives or other compression methods (those
  pages report a non-fatal `error`), and it does not check CRCs. A page may
  not exceed 256 MB after decompression.

**JPEG 2000** (`.jp2`, `.j2k`, `.j2c`) is what archive.org uses for the page
scans in its `*_jp2.zip` downloads. Browsers other than Safari cannot show it,
so MiniMedi decodes it itself, in a background worker (about a second for a
2400x3600 page; the page does not freeze), and draws the result on a canvas.
The decoder is loaded only when such a page (or a single JPEG 2000 image)
appears. It handles 8-bit
grayscale and RGB(A); other colour spaces (sYCC, CMYK, palettes) and ICC
profiles are not converted, images above 64 megapixels are refused, and the
worker starts from a `blob:` URL, so a strict Content-Security-Policy needs
`worker-src blob:`.

Reading comics: `MediaSource.startPage` (1-based) opens on a given page, so a
host that remembers the reader's place from the `positionChange` events can
bring them back to it. A changed value moves an open comic to that page, so the
host can steer it later too (the reader's own turning does not change it).
`readingDirection: "rtl"` is for manga: the left arrow key goes on, the right
one goes back, and the Next button sits on the left. A double click on a page
toggles between fitting it to the viewer and its natural size.

The reader can go to any page: with the slider, or by typing a page number into
the "Go to page" field and pressing Enter. Below the pictures, buttons switch
between **single page**, **double page** and **scroll** (`MediaSource.pageView`
sets the start, `"single"` by default). In the double-page view two pages lie side by
side, in reading order (the right one first for `rtl`), and Next, Previous and
the arrow keys turn two pages at once:

- The first page is the cover and stands alone, so the pairs are 2-3, 4-5, ...
  The "Cover alone" button turns that off (1-2, 3-4, ...), which fixes scans
  whose pairs come out off by one.
- A page that is wider than tall is already a spread: it is shown alone, and so
  is the page it would have been paired with. The pairs after it stay as they
  were.
- `positionChange` names the first page of the pair. Selecting text, searching
  and the marks on matches work on each page of the pair.

The **scroll** view puts all pages one below the other, like a webtoon. Each
page is a box of its size from the start (measured once it has been read, the
middle size of the pages read so far before), so the scroll bar is about right
and pages do not jump. Only the pages near what is on view are read and held:
a page more than about a screen away is given back, so a book of hundreds of
large pages stays small in memory.

- The page label, the slider, `positionChange` and the search follow the page at
  a reading line 40 % down the box. Going to a page (field, slider, Next,
  search, `startPage`) scrolls it to the top; this does not move the page again
  if you scroll on while the pictures load.
- Up and Down scroll by a line, Page Up and Page Down by a screen, Left and Right
  go to the previous and next page. Fit shows each page as wide as the viewer
  (never enlarged); a double click shows natural size.
- Text selection, search and marks work on every page that is read. Pages that
  cannot be read show a message in their place and give a non-fatal `error`.
- When a page is read and its box changes from the estimate to the real size,
  the page under the reading line stays where it was (MiniMedi does this itself
  and switches the browser's scroll anchoring off for the box). The scroll bar
  stays an approximation until the pages have been read.
- Limit: the last pages cannot reach the top of the box when they are shorter
  than it.

**RAR (CBR), 7z (CB7), tar (CBT) and compressed tar** are read by
[libarchive.js](https://github.com/nika-begiashvili/libarchivejs)
(libarchive as WASM, in a worker), loaded only when such a file is opened. It
works without setup: the library carries a copy of the worker and the WASM
file (1.4 MB) and starts it from a `blob:` URL. RAR 5 is tested; RAR 4 (older
`.cbr` files) is read by the same code but has not been tested. For 7z, archives
made by py7zr 1.1.4 are tested (LZMA2, and stored without compression); other
7z methods are not. For tar, the POSIX and the GNU flavor are tested, and so are tar files
compressed with gzip, bzip2 and xz (found by the mark of the compression; the
tar inside is read by libarchive, so a gzip file that is no tar ends in "no
images"). A very old tar without the `ustar` mark is not recognized, unless it
is compressed. The whole archive is copied into the library's
memory, and a page is found by reading the archive from the start, so late
pages of a "solid" archive (RAR, or a 7z made that way) take longer
(about 70 ms for page 40 of 40 in a test RAR of 110 kB pages). Encrypted
archives cannot be opened; the error says so. The library needs a recent browser
(it uses `Promise.withResolvers`).

With a strict Content-Security-Policy (the bundled copy needs `worker-src blob:`
and `connect-src data:`), serve two files from your own origin, next to each
other, and tell MiniMedi where:

```ts
import { configureArchiveWorker } from "minimedi";

// copy node_modules/libarchive.js/dist/worker-bundle.js and libarchive.wasm
// to the same folder of your site
configureArchiveWorker({ workerSrc: "/assets/libarchive/worker-bundle.js" });
```

**Security.** The bundled libarchive is version 3.7.2, and libarchive.js has not
been updated since January 2024. Later libarchive releases fixed bugs in the
RAR reader (among them out-of-bounds accesses in two of its filters, fixed in
3.7.4). The parser runs inside the WASM sandbox of a worker, so it cannot touch
your page directly, but a crafted RAR could still crash the worker or expose
memory inside it. The fixes named above concern the RAR reader; whether the 7z
and tar readers of 3.7.2 have comparable problems has not been checked. Only RAR,
7z, tar and compressed files go to libarchive (found by their first bytes); ZIP archives are
read by MiniMedi's own reader. If your app opens such files from sources you do
not trust, turn them off, or pass a newer build in the form described above:

```ts
configureArchiveWorker({ enabled: false }); // the viewer then reports an error for .cbr, .cb7 and .cbt files
```

### Recognized text (hOCR)

MiniMedi does not recognize text itself and defines no OCR format of its own:
it reads **hOCR**, the HTML format of Tesseract and the Internet Archive (the
`*_hocr.html` that comes with a book's `*_jp2.zip`).

```ts
import { alignOcrPages, parseHocr } from "minimedi";

const pages = parseHocr(await (await fetch("book_hocr.html")).text()); // OcrPage[]
const perImage = alignOcrPages(pages, imageNames); // one entry per image, or undefined
```

- An `OcrPage` holds blocks (paragraphs), lines and words, each with a box in
  pixels (`x`, `y`, `width`, `height`) of the image the OCR ran on. That size is
  in `OcrPage.width` and `.height` and can differ from the image you show:
  scale by shown size / OCR size.
- Pages are matched to images by file name, taken from the `image "..."` in
  each page's `title`. The page number (`ppageno`) is not used: Tesseract writes
  0 for every page of a multi-page file.
- Text lines are `ocr_line` and also `ocr_caption`, `ocr_header` and
  `ocr_textfloat` (the line's `role`). Photos and separators have no text and
  are skipped. Lines without words, and words directly in a paragraph, are
  accepted. `confidence` is 0 to 1 (`x_wconf`); recognition on comics is noisy,
  so keep it.
- `language` is whatever the engine wrote (Tesseract: three-letter codes such
  as `fra`).
- It needs `DOMParser`, so it runs in the browser (and in jsdom). A 1.3 MB file
  with 62 pages took about 0.1 s in Firefox and in Chrome.

#### Writing hOCR for MiniMedi (for converters)

Another engine than Tesseract (PaddleOCR, docTR, a speech-bubble detector with
manga-ocr, ...) does not need support in MiniMedi: write its result as hOCR and
pass that as `MediaSource.ocr`. This is the part of hOCR that is read; anything
else in the file is ignored.

```html
<html><body>
<div class="ocr_page" title="image &quot;Book_0007.jp2&quot;; bbox 0 0 1200 1800">
  <div class="ocr_carea" lang="fra">
    <p class="ocr_par" lang="fra" title="bbox 100 120 700 260">
      <span class="ocr_line" title="bbox 100 120 700 180">
        <span class="ocrx_word" title="bbox 100 120 260 180; x_wconf 92">Bonjour</span>
        <span class="ocrx_word" title="bbox 280 120 400 180; x_wconf 88">le</span>
        <span class="ocrx_word" title="bbox 420 120 700 180">monde</span>
      </span>
      <span class="ocr_line" title="bbox 100 200 520 260">Une ligne sans mots</span>
    </p>
  </div>
</div>
</body></html>
```

- **Page.** One `ocr_page` per image. Its `title` carries `bbox 0 0 W H`, the size
  in pixels of the image the engine saw, and `image "name"`, the file name of that
  image; the last part of the path is used and it is compared after Unicode
  normalization (NFC). Give every page a different name. Without any image names,
  the pages are matched by position if there are as many as images. A page
  without a `bbox` is skipped.
- **Boxes.** `bbox x0 y0 x1 y1` in pixels of that image, origin top left, with
  x1 >= x0 and y1 >= y0 (otherwise the element is skipped). It may be on the page,
  paragraph (`ocr_par`), line and word.
- **Text.** Paragraphs (`ocr_par`) are what a selection or a search sees as
  running text; a phrase must lie inside one. Lines are `ocr_line` (also
  `ocr_caption`, `ocr_header`, `ocr_textfloat`). Words are `ocrx_word` (or
  `ocr_word`). A line may have no word elements: its own text is then used, and a
  selection or a search match marks the whole line. For a speech bubble, one
  paragraph with one line is the right shape.
- **Optional.** `x_wconf` (0 to 100) on a word, `lang` on `ocr_carea` or `ocr_par`,
  `textangle` on a line (the angle is passed on, but the text is laid out
  upright: rotated and vertical text can be selected, the highlight may not fit).
- **Order.** Elements are read in document order, which is the reading order for
  selecting and searching. Nesting is forgiving: a word outside any line, or a
  line outside any paragraph, gets one made for it.
- Whitespace in text is squeezed. Elements without text (photos, separators) are
  skipped.

#### Selecting the text on the picture

Pass the recognized text as `MediaSource.ocr` for `type: "image"` or
`type: "comic"`: hOCR as a string or a `Blob`/`File`, or pages you already read
with `parseHocr`. MiniMedi then lays the words of the page on view over the
picture, invisibly, so that the browser's own selection works on them: double
click a word, drag over a sentence, or use the touch handles.

```ts
<MiniMedi
  source={{ type: "comic", url, blob: file, ocr: hocrFile }}
  onEvent={(e) => {
    if (e.event === "selection") {
      // e.text: "Bonjour le monde"; e.position.page: 6 (comics);
      // e.position.region: { x, y, width, height } in fractions (0 to 1) of the page
    }
  }}
/>
```

- **Event.** A `selection` event fires when a selection has settled (mouse
  button released, or a short pause for touch handles). `text` joins the words of
  a paragraph with spaces and separates paragraphs by a newline; a word that is
  only partly selected counts only as far as it is selected. `position.region`
  is the area of all touched words as fractions of the page, so it does not depend
  on the OCR size or the zoom. Comics also give `position.page` (1-based).
- **Matching.** Comic pages are matched to OCR pages by image file name (see
  `alignOcrPages`); a page without OCR text just has no layer. A single image uses
  the OCR page with its file name, or the only page there is.
- **Zoom.** A double click on a word in a comic selects it and does not zoom
  (elsewhere it still does). In the image viewer a click zooms as before, except
  while text is selected. The layer follows the picture when it is fitted or
  shown at natural size.
- **Errors.** Unusable OCR data gives a non-fatal `error` event with
  `scope: "ocr"`; the picture stays visible. Keep an array's identity stable
  across renders (it is read again when it changes).
- **Limits.** Lines that the engine marks as rotated (`textangle`) or that run
  vertically are selectable, but their highlight may not match the box: only
  horizontal text is laid out exactly. Mixed-script or right-to-left text is
  untested.

#### Searching the text

With `MediaSource.ocr`, the image and comic viewers show a search field above
the picture. It searches the recognized text of the **whole book**: matches are
marked on the page, Enter (or the buttons) moves to the next match and shows its
page, Shift+Enter goes back, Escape clears. Every change sends a `searchChange`
event.

- Case, accents on Latin letters and punctuation do not matter ("asterix" finds
  "Astérix!"); other scripts keep their marks. Part of a word matches, so the
  search can run while typing.
- Several words are a phrase: they must follow each other in one paragraph
  (across line breaks). A word split by a hyphen at the end of a line is not
  joined.
- If the engine gave lines without words, the whole line is marked.
- Keys typed in the field do not turn comic pages.

To search without the viewer (for your own list of results), use the same logic:

```ts
import { alignOcrPages, createOcrSearchIndex, parseHocr } from "minimedi";

const pages = alignOcrPages(parseHocr(hocr), imageNames); // one entry per image
const matches = createOcrSearchIndex(pages).search("chat noir");
// matches[0]: { page (0-based), text, boxes, region }, boxes in fractions (0 to 1) of the page
```

### Standalone subtitle transcripts

Passing a `.srt`/`.vtt`/`.lrc`/UltraStar file itself as the `MediaSource` (`type:
"subtitle"`) renders it as a scrollable, clickable transcript instead of
attaching it to a video. Optionally attach a video/audio file via
`mediaUrl`/`mediaKind` to sync playback and enable click-to-seek on any
line.

**LRC lyrics** (`[mm:ss.xx]line`) are read like SRT/VTT, found by their content and
not by the file name, so they also work as `subtitleUrls` of an audio file. LRC
has start times only: a line lasts until the next one starts (the last one five
seconds), and an empty time line such as `[01:20.00]` ends the line before it.
Supported are several time tags on one line (a repeated chorus), lines with the
same time (shown together, e.g. with a translation), `[offset:+/-ms]` (a
positive value makes lines appear sooner, as the format's description says;
players differ here) and enhanced LRC word marks (`<mm:ss.xx>`, dropped; the
words are shown, but not highlighted one by one). Other tags (`[ti:]`, `[ar:]`, ...)
are ignored.

**UltraStar song files** (the `.txt` of UltraStar Deluxe, Vocaluxe, Performous, ...)
are read the same way, by content: a `#BPM` header and at least one note
make a file one. Every phrase (the notes up to the next `-` line) becomes a cue
from the start of its first note to the end of its last one; the syllables are
joined as written. Timing follows the format specification (a beat lasts
15 / BPM seconds, beat 0 lies `#GAP` ms into the audio; `#START` and `#END`
move nothing). Relative mode (`#RELATIVE:YES`, old files) is supported; the
variable-BPM lines (`B`) of some old files are ignored, as UltraStar Deluxe
does. In a duet every phrase gets its singer's name in front (the `#P1`/`#P2`
header, or "P1"/"P2"); where two voices sing at once, the player shows the
earlier cue only (the transcript shows both). Only the lyrics are used:
pitches, golden notes, rap and freestyle marks are not shown, and a syllable
that is just `~` (a held note) adds time but no text. The file name `.txt`
says nothing, so pass `type: "subtitle"` yourself when the file is the
`MediaSource`; as an entry of `subtitleUrls` it is recognized by content.

**Text encoding.** Subtitle files are read as UTF-8; a file that is not valid UTF-8
is read as Windows-1252, or as the encoding of its `#ENCODING:` header
(`CP1250` or `CP1252`, UltraStar files only). Valid UTF-8 always stays UTF-8.

### Translating the texts (`labels`)

Every text MiniMedi shows (button names, `aria-label`s, titles, status and error
lines) can be replaced with the `labels` prop. Missing entries keep their English
default, so a partial translation is fine. `{name}` marks values MiniMedi fills in.

```tsx
<MiniMedi
  source={source}
  labels={{
    previous: "Zurück",
    next: "Weiter",
    pageOf: "Seite {page} / {total}",
    hideTrack: "{track} ausblenden",
  }}
/>
```

`defaultLabels` (exported) lists all keys with their English text, and the type
`MiniMediLabels` describes them. An inline `labels` object is fine: it is compared by
content, not identity. If you render an exported viewer on its own (`ComicViewer`,
`BookViewer`, ...), wrap it in `<MiniMediLabelsProvider labels={...}>`.

Not covered: the `message` of `error` events (meant for your logs; show your own text per
`scope`), and the browser's own controls (`nativeControls`, file dialogs).

### Fallback for unknown types

If `source.type` doesn't match one of the known types (e.g. `.docx`,
`.zip`, ...), MiniMedi shows a simple download link (`DownloadFallback`)
instead of an error.

### Data fetching

MiniMedi never fetches the primary media itself (no internal `fetch()`
for `source.url`) - every viewer relies on the browser to resolve it
directly (`<video src>`, `<audio src>`, `<iframe src>`). Two narrow,
documented exceptions exist: loading external subtitle files (needs
parsing) and reading a video's bytes to detect/extract embedded subtitle
tracks (needs container parsing). All of these requests are aborted when
the source changes or the viewer unmounts.

Embedded subtitles are read as a **stream**, never as a whole file:

- **MKV:** detecting the tracks reads only the start of the file (the track
  list sits there). Selected tracks are extracted in a single streamed pass
  over the file; the file is never held in memory as a whole, and there is
  no size limit. Measured on a 688 MB MKV in Chromium: tracks listed in
  under a second, extraction in about 4 s. While a pass is running,
  `embeddedSubtitlesProgress` events report how far it is.
  The pass does not decode the whole file: it walks the Matroska element
  headers and hands only the file header, the track list and the blocks of
  the wanted tracks to the subtitle decoders. Video and audio payload is
  skipped without being copied or parsed, so the work per byte is small and
  reading the source is what remains. A file layout this does not understand
  falls back to reading everything with the full decoders (same result,
  slower). To compare the two ways, run
  `localStorage.setItem("minimedi:legacy-scan", "1")` in the console and
  reload; remove the key to switch back.
- **MP4:** extracting a track makes the MP4 parser (mp4box) keep the file in
  memory (measured: roughly the file size), because the track list (moov box)
  often comes after the media data. Files above `embeddedScanMaxBytes`
  (default 1 GB) are therefore skipped with a non-fatal `error` event. Only
  listing the tracks does not keep the data.
- **Local files:** pass the `File`/`Blob` as `source.blob` so MiniMedi reads
  it directly (and knows its size) instead of fetching the object URL.
- **Remote URLs:** reading needs CORS headers on the video URL, and extracting
  a track streams the whole file over the network once. Set
  `scanEmbeddedSubtitles: false` where you don't need embedded tracks.
Text selection in `TextViewer` only
works for same-origin URLs (e.g. `blob:` URLs).

## Architecture

```text
MiniMedi
│
├── Core          MediaSource resolution, event bus, types, subtitle
│                 parsing (external + embedded MKV/MP4 extraction),
│                 ZIP reader and page list for comic archives
├── Viewers       TextViewer, PdfViewer, PdfViewerIframe, AudioViewer,
│                 VideoViewer, EpubViewer, SubtitleViewer, ImageViewer,
│                 ComicViewer
├── Components    MiniMedi (picks a viewer based on type), DownloadFallback
└── examples/     Standalone demo app (file-upload player)
```

## Roadmap

Done: PDF fine-tuning, subtitles (external and embedded, text and image
tracks, several at once), the full event set, the player controls with the
subtitle menu, EPUB navigation, FB2/MOBI/AZW3 books (also `.fb2.zip`), images and comic
archives (CBZ, CBR, CB7, CBT, compressed tar, JPEG 2000), LRC and UltraStar lyrics, restoring
the reading position of comics, EPUB and e-books.

Next:

- OCR for image subtitles, single images and comic pages. The format is hOCR
  (reading it, the selectable text layer over images and comic pages, and
  searching the text of a book are done). MiniMedi does not recognize text
  itself; converters for other engines belong to the host, and the hOCR that is
  read is described for them ("Writing hOCR for MiniMedi"). Next: OCR text for
  image subtitles (PGS).
- A plugin system.
- A stable package (1.0) and complete documentation.

## Non-goals

MiniMedi deliberately will **not** grow user management, login, storage,
vocabulary cards, AI requests, RAG, translations, or learning statistics.
Those belong in applications that embed MiniMedi.

## License

Copyright (C) 2026 Jan Burkhardt. MiniMedi is free software under the
**GNU Affero General Public License, version 3 or (at your option) any later version**
(`AGPL-3.0-or-later`); the full text is in `LICENSE`.

What that means for an app that embeds MiniMedi: the app and MiniMedi are combined into one
program, so the app has to be offered to its users under the same license, together with its
complete source code (for a web app, the code served to the browser counts). Whoever modifies
MiniMedi and lets users interact with it over a network must offer them the source of the
modified version (section 13). A program that only talks to such an app over a network, such as
a separate backend, is generally a separate work. This is a summary, not legal advice; the
license text decides.

**Other licenses.** The copyright holder can license MiniMedi to you under other terms (for
example a commercial license that does not require opening your app's source). Contact the
maintainer through the GitHub repository. Because of this, outside contributions are only
accepted after an agreement that allows relicensing: open an issue before sending code.

**Third-party code.** `dist/` bundles third-party code (all of it permissively licensed: MIT, ISC,
BSD, Apache-2.0; `jszip` is offered under MIT or GPL-3.0 and used under MIT). Their license
texts ship with the package as `THIRD-PARTY-NOTICES.md`. The file is generated from a real
build (the packages found in its source maps, plus the libarchive that is compiled into the
WebAssembly of `libarchive.js`): run `pnpm notices` after changing dependencies. CI runs
`pnpm notices:check` and fails if the file is out of date. Two bundled packages
(`marks-pane`, `path-webpack`) ship no license file; their `package.json` names MIT and the
author, and the notices say so.

## AI assistance

Parts of the code, tests and documentation were written with Claude (Anthropic) in chat
sessions.

## Subtitle layout

All chosen subtitle tracks are drawn at once, top to bottom in the order given
(`subtitleUrls` first, then `embeddedSubtitleTrackIds`), and never overlap:
text tracks stack by their real height, image (PGS) tracks in steps of 12 % of
the player height. `subtitleLayout` changes that per track. The key of a track
is `embedded:<id>` or the subtitle URL, the same value `subtitleChange` events
report as `source`.

```ts
source = {
  ...,
  subtitleLayout: {
    tracks: {
      "embedded:4": { hidden: true },        // not drawn; data stays loaded, events keep firing
      "/movie.de.srt": { offsetPercent: 30 }, // lifted 30 % of the player height above its
                                              // standard spot; leaves the automatic stacking
                                              // (negative: lowered; text stops at the bottom edge)
    },
    stackStepPercent: 12,                    // gap between stacked image tracks
  },
};
```

Changing the layout never reloads a track. Audio has no picture to place text
on, so only `hidden` applies there. The demo has controls for both.

## Prefetching embedded subtitles

MKV stores subtitle blocks between the video and audio blocks, so reading a track
means reading the whole file. By default that happens when a track is chosen, and
**again for every further track** (a 4.8 GB remux took about 30 s each time).

`prefetchEmbeddedSubtitles: true` reads **all** tracks in one background pass right
after they are detected (about 0.3 s after loading). Afterwards every track shows at
once, and a track chosen while the pass runs waits for it instead of starting another.
It costs one read of the whole file (disk and some CPU, also while the video starts)
and keeps the extracted tracks in memory. Progress is reported through
`embeddedSubtitlesProgress`, like before. Off by default.

## Subtitle menu

When the file has embedded subtitle tracks (or `subtitleUrls` are given), the control
bar shows a **CC** button. Its menu lists every track; embedded tracks have a checkbox,
and every chosen track has an eye button to hide and show it.

MiniMedi never changes its own props, so the menu works through events:

- **Checkbox:** fires `trackSelectionChange` with the new `trackIds`. Your app applies
  it by putting them into `embeddedSubtitleTrackIds`:
  ```ts
  onEvent={(e) => {
    if (e.event === "trackSelectionChange") {
      setSource((s) => ({ ...s, embeddedSubtitleTrackIds: e.trackIds }));
    }
  }}
  ```
  Without that, the checkbox changes nothing.
- **Eye:** works on its own (MiniMedi keeps it) and fires `subtitleVisibilityChange`
  (`source`, `hidden`). Mirror it into `subtitleLayout` if your app keeps that state; the
  menu's choice wins over the prop for the tracks it has toggled.

`C` opens and closes the menu, `Esc` or a click elsewhere closes it. In fullscreen it
stays visible and keeps the bar from fading out. Audio and `nativeControls: true` have no menu.

## Player controls

Video uses MiniMedi's own control bar (play/pause, time, seek bar, volume,
fullscreen) instead of the browser's. The reason: native fullscreen only
enlarges the `<video>` element, so subtitles that MiniMedi draws itself
(text lines and PGS bitmaps) disappeared. MiniMedi's fullscreen button
fullscreens the whole player, so they stay visible. In fullscreen the bar
and the cursor hide after 2.5 s without movement while playing.

| Key (player focused) | Action |
| --- | --- |
| Space / K | play / pause |
| ← / → | 5 s back / forward |
| ↑ / ↓ | volume |
| M | mute |
| F | fullscreen (also: double click) |
| C | subtitle menu |

A click on the video toggles play/pause.

Set `nativeControls: true` on the `MediaSource` to use the browser's own
controls again (no MiniMedi subtitles in native fullscreen then). Audio and
the video inside the subtitle transcript viewer still use native controls.

Text subtitles are looked up every frame while playing (`timeupdate` only
fires about four times per second).

## Security notes

MiniMedi shows content it did not create, so a few rules apply:

- Subtitle and cue text is rendered as plain text, never as HTML.
- The text viewer's `<iframe>` is sandboxed (`allow-same-origin`, no scripts): a
  text/HTML file cannot run code, while text selection keeps working. EPUB chapters
  are rendered by epubjs in a sandboxed frame without scripts as well, and so
  are the chapters of FB2/MOBI/AZW3 books (see "E-books").
- URLs with a code-running scheme (`javascript:`, `vbscript:`) are refused. A bad
  main `url` shows a notice and fires a fatal `error` event instead of crashing the
  host app; bad `subtitleUrls`/`mediaUrl` are dropped and reported as non-fatal errors.
- `pdfMode="iframe"` and `DownloadFallback` hand the URL to the browser. Only pass
  URLs you trust there; a PDF iframe cannot be sandboxed without breaking the
  browser's PDF viewer.
- Parsers (MKV, MP4, PDF, EPUB, FB2/MOBI/AZW3, PGS) read untrusted binary data. A crafted file can
  still make a tab slow or run out of memory; MiniMedi limits what it reads
  (see `embeddedScanMaxBytes`) but this is not a guarantee.

## Browser smoke tests

`pnpm test` runs in Node and cannot see browser-only failures (workers,
canvas, `<video>`). `pnpm test:browser` opens the demo app in a real browser
(puppeteer-core, no browser is downloaded for you) and checks PDF, EPUB,
text subtitles (SRT, ASS, mov_text) and PGS image subtitles, including a
zlib-compressed PGS track.

```bash
pnpm fixtures   # ffmpeg; mkvmerge (mkvtoolnix) is optional, adds the compressed-PGS file
MINIMEDI_BROWSER=firefox MINIMEDI_BROWSER_PATH=/usr/bin/firefox pnpm test:browser
MINIMEDI_BROWSER=chrome  MINIMEDI_BROWSER_PATH=/usr/bin/chromium pnpm test:browser
```

Firefox needs a recent version (puppeteer drives it over WebDriver BiDi).
A system Firefox installed as a snap often fails to start under puppeteer;
`pnpm dlx @puppeteer/browsers install firefox@stable` downloads a plain one
into `./firefox/` (git-ignored) and prints its path.
